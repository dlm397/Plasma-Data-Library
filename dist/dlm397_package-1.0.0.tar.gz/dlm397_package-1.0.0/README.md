### Description
> Making a library of the common functions I use in processing plasma flux data. Hopefully it can be passed on to others after I upload my current progress and polish it. This will be updated.

Currently only setting up fundamental funcations like reading and writing data, change configurations, and setting up storage, there are no extrenally applicable functiont.
